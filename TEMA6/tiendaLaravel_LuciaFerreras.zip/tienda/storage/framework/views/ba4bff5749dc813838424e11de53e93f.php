<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent("titulo"); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')("resources/css/app.css"); ?>
</head>
<body class="">
    <?php echo $__env->make("layouts.partials.nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <?php echo $__env->yieldContent("contenido"); ?>
    </div>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\examen\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>