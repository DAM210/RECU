<?php $__env->startSection('titulo','Tienda'); ?>
<?php $__env->startSection('contenido'); ?>
<h1 class="text-3xl font-bold underline">Los productos de la tienda</h1>
<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="grid grid-cols-3 gap-2">
    <?php if($producto->imagen!=null): ?>
        <div class="px-5 py-8 border rounded border-green-500">
            <img src="<?php echo e(asset('assets/imagenes/'.$producto->imagen->url)); ?>" alt="<?php echo e($producto->nombre); ?>">
        </div>
    <?php endif; ?>
    <div class="col-span-2 px-5 py-8 border rounded border-green-500">
        <ul>
            <li>Nombre: <span class="font-light"><?php echo e($producto->nombre); ?></span></li>
            <hr>
            <li>Precio: <span class="font-light"><?php echo e($producto->precio); ?></span> €</li>
            <hr>
            <li>Familia: <span class="font-light"><?php echo e($producto->familia->nombre); ?></span></li>
            <hr>
            <li>Descripción: <span class="font-light"><?php echo e($producto->descripcion); ?></span></li>
        </ul>
        <div class="mt-4">
            <a href="<?php echo e(route('productos.show', $producto)); ?>" class="bverde">Ver producto</a>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tienda\resources\views/productos/index.blade.php ENDPATH**/ ?>