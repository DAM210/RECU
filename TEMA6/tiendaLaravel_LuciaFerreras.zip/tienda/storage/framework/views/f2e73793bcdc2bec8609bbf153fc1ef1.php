<?php $__env->startSection('titulo','Mostrar '.$producto->titulo); ?>
<?php $__env->startSection('contenido'); ?>
<?php echo csrf_field(); ?>
<?php echo method_field('delete'); ?>
<h1 class="text-3xl font-bold underline">Vista en detalle del producto</h1>

<div class="grid grid-cols-3 gap-2">
    <div class="px-5 py-8">
        <img src="<?php echo e(asset('assets/imagenesProducto/'.$producto->imagen->url)); ?>" alt="<?php echo e($producto->imagen->url); ?>">
    </div>
    <div class="col-span-2 px-5 py-8">
        <ul>
            <li><?php echo e($producto->titulo); ?></li>
            <hr>
            <li>Precio: <span class="font-light"><?php echo e($producto->precio); ?></span> €</li>
            <hr>
            <li>Familia: <span class="font-light"><?php echo e($producto->familia->descripcion); ?></span></li>
            <hr>
            <li>Descripción: <span class="font-light"><?php echo e($producto->descripcion); ?></span></li>
            <hr>
        </ul>
    </div>
    <div class="col-span-2 px-5 py-8">
        <a href="<?php echo e(route('productos.edit',$producto)); ?>" class="bverde">Editar producto</a>
        <a href="<?php echo e(route('productos.destroy',$producto)); ?>" class="bverde">Eliminar producto</a>
        <a href="<?php echo e(route('productos.index')); ?>" class="bverde">Volver a la tienda</a>
    </div>
    <br><br>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examen\resources\views/productos/show.blade.php ENDPATH**/ ?>