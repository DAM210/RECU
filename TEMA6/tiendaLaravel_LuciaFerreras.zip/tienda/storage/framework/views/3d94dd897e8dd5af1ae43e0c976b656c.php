<?php $__env->startSection('titulo','Editar el producto'); ?>
<?php $__env->startSection('contenido'); ?>
<h1 class="text-3xl font-bold underline">Edición del producto</h1>
    <div class="grid grid-cols-2 gap-y-4 ml-10">
        <form action="<?php echo e(route('productos.update', $producto)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <br>
            <div class="mb-1">
                <label>
                    <a class="font-semibold">Titulo: </a>
                    <input type="text" id="titulo" name="titulo" required value="<?php echo e($producto->titulo); ?>" placeholder="--Introducir titulo--">
                </label>
            </div>
            <br>
            <hr><br>
            <div class="mb-1">
                <label>
                    <a class="font-semibold">Precio: </a>
                    <input type="number" id="precio" name="precio" required value="<?php echo e($producto->precio); ?>" placeholder="--Introducir precio--">
                </label>
            </div>
            <br>
            <hr><br>
            <div class="mb-1">
                <label>
                    <a class="font-semibold">Familia: </a>
                    <select id="familia" name="familia">
                        <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($familia->id); ?>" <?php echo e($producto->familia_id == $familia->id ? 'selected' : ''); ?>><?php echo e($familia->descripcion); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
            </div>
            <br>
            <div class="mb-1">
                <label>
                    <a class="font-semibold">Descripción: </a>
                    <br><br>
                    <textarea id="descripcion" name="descripcion" style="height: 150px;width: 400px;" required placeholder="--Introducir descripción--"><?php echo e($producto->descripcion); ?></textarea>
                </label>
                </div><br>
            <hr><br>
            <div class="mb-1">
                <a class="font-semibold">Imagen: </a>
                <input type="file" id="imagen" name="imagen" value="<?php echo e($producto->imagen); ?>">
                <img src="<?php echo e(asset('assets/imagenesProducto/' . $producto->imagen->url)); ?>" alt="<?php echo e($producto->titulo); ?>">
            </div>
            <br>
            <hr><br>
            <div class="col-start-1 mb-10">
                <input type="submit" id="modificar" class="bverde" name="modificar" value="Modificar producto">
                <a href="/productos" class="bverde">Ver tienda</a>
            </div>

        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examen\resources\views/productos/edit.blade.php ENDPATH**/ ?>