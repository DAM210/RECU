<?php $__env->startSection('titulo', 'Alta del producto'); ?>
<?php $__env->startSection('contenido'); ?>
<h1 class="text-3xl font-bold underline">Alta del producto</h1>
    <div class="grid grid-cols-2 gap-y-4 ml-10">
    <form action="<?php echo e(route('productos.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-1">
                <label>
                    <a>Titulo: </a>
                    <input type="text" id="titulo" name="titulo" required placeholder="--Introducir titulo--">
                </label>
            </div>
            <div class="mb-1">
                <label>
                    <a>Precio: </a>
                    <input type="number" id="precio" name="precio" required placeholder="--Introducir precio--">
                </label>
            </div>
            <div class="mb-1">
                <label>
                    <a>Familia: </a>
                    <select id="familia" name="familia">
                        <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($familia->id); ?>"><?php echo e($familia->descripcion); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </label>
            </div>
            <div class="mb-1">
                <label>
                    <a>Imagen: </a>
                    <input type="file" id="imagen" name="imagen">
                </label>
            </div>
            <div class="mb-1">
                <label>
                    <a class="font-semibold">Descripción del producto: </a>
                    <br><br>
                    <textarea id="descripcion" name="descripcion" style="height: 150px;width: 400px;" required
                    placeholder="--Introducir descripción--"></textarea>
                </label>
            </div>
            <div class="col-start-1 mb-10">
                <input type="submit" id="anyadir" class="bverde" name="anyadir" value="Añadir producto">
                <a href="/productos" class="bverde">Ver tienda</a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examen\resources\views/productos/create.blade.php ENDPATH**/ ?>